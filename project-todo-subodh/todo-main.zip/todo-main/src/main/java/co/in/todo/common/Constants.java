package co.in.todo.common;

public class Constants {

	public static final String SUCCESSFULLY_CREATED_DATA = "Data created successfully";
	
	public static final String SUCCESSFULLY_FETCHED_DATA = "Data fetched successfully";
	
	public static final String SUCCESSFULLY_UPDATED_DATA = "Data updated successfully";
	
	public static final String SUCCESSFULLY_DELETED_DATA = "Data deleted successfully";

}
