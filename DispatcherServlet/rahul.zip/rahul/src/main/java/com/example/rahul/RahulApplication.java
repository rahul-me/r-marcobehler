package com.example.rahul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RahulApplication {

	public static void main(String[] args) {
		SpringApplication.run(RahulApplication.class, args);
	}

}
