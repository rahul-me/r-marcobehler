package com.example.rahul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RahulApplicationTests {

	@Test
	void contextLoads() {
	}

}
