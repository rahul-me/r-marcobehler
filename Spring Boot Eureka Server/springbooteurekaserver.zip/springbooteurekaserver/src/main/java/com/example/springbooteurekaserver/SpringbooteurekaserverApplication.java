package com.example.springbooteurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbooteurekaserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbooteurekaserverApplication.class, args);
	}

}
