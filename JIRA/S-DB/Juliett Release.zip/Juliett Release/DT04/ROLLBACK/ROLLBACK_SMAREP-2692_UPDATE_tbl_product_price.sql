USE [Titan]

-- H01H192
UPDATE tbl_Product_Prices SET price = 17.50 where product_id = 2253;

-- H01H191
UPDATE tbl_Product_Prices SET price = 12.50 where product_id = 2252;

-- H01H190
UPDATE tbl_Product_Prices SET price = 7.50 where product_id = 2251;

