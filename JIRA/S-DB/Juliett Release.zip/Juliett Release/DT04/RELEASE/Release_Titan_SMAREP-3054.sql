USE [Titan]
Go

INSERT INTO [tbl_Ticket_Distribution_Types]
([distribution_type],[active],[distribution_code],[sort_order])
VALUES
('Not Applicable',1,'N',5)