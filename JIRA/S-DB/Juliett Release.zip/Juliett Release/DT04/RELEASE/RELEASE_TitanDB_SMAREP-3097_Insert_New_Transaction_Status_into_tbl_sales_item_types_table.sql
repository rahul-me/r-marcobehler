USE [Titan]
GO

INSERT INTO tbl_sales_item_types(sales_item_type_desc, smart_type_code) VALUES('Pending Refund', 'J');
INSERT INTO tbl_sales_item_types(sales_item_type_desc, smart_type_code) VALUES('Pending Reversal', 'H');
INSERT INTO tbl_sales_item_types(sales_item_type_desc, smart_type_code) VALUES('Payment Reversed', 'I');