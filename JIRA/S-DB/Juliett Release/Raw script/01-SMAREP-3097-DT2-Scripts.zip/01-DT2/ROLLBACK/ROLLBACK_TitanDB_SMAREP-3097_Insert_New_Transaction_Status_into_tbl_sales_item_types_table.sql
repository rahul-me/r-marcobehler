USE [Titan]
GO

DELETE FROM tbl_sales_item_types WHERE smart_type_code = 'H';
DELETE FROM tbl_sales_item_types WHERE smart_type_code = 'I';
DELETE FROM tbl_sales_item_types WHERE smart_type_code = 'J';