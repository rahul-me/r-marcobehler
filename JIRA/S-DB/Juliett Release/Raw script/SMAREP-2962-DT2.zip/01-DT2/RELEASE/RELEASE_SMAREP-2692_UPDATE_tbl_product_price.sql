USE [Titan]

-- H01H192
UPDATE tbl_Product_Prices SET price = 20.00 where product_id = 2253;

-- H01H191
UPDATE tbl_Product_Prices SET price = 15.00 where product_id = 2252;

-- H01H190
UPDATE tbl_Product_Prices SET price = 10.00 where product_id = 2251;