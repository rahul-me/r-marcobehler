USE [Titan]
GO

IF OBJECT_ID(N'dbo.tbl_Phone_Contacts_Country_Code', N'U') IS NOT NULL  
   DROP TABLE [dbo].[tbl_Phone_Contacts_Country_Code];  
    
GO   

